<!-- Footer -->
<footer class="w3-container w3-light-green" style="position:absolute;bottom:0;width:100%;text-align:center">
    <h4 style="font-size:14px;margin:0;padding:0">Jyoti Ayur Clinic</h4>
    <p style="font-size:12px;margin:0;padding:0">copyright since 2021-22</p>
</footer>

<!-- End page content -->
