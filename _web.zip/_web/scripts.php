 <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
 <script src="assets/js/jquery.min.js"></script>

 <script src="assets/js/bootstrap.bundle.min.js"></script>

 <script src="assets/js/meanmenu.min.js"></script>

 <script src="assets/js/owl.carousel.min.js"></script>

 <script src="assets/js/wow.min.js"></script>

 <script src="assets/js/nice-select.min.js"></script>

 <script src="assets/js/magnific-popup.min.js"></script>

 <script src="assets/js/mixitup.min.js"></script>

 <script src="assets/js/bootstrap-datepicker.min.js"></script>

 <script src="assets/js/form-validator.min.js"></script>

 <script src="assets/js/contact-form-script.js"></script>

 <script src="assets/js/ajaxchimp.min.js"></script>

 <script src="assets/js/custom.js"></script>