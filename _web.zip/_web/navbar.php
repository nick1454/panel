  <div class="navbar-area">
            <div class="mobile-nav">
                <div class="container">
                    <div class="mobile-menu">
                        <div class="logo">
                            <a href="index.php">
                                <img src="assets/images/logo.png" style="max-width: 200px;">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="desktop-nav">
                <div class="container">
                    <nav class="navbar navbar-expand-md navbar-light">
                        <a class="navbar-brand" href="index.php">
                            <img src="assets/images/logo.png" style="width: 524px;">
                        </a>
                        <div class="collapse navbar-collapse mean-menu">
                            <ul class="navbar-nav m-auto">
                                <li class="nav-item">
                                    <a href="index.php" class="nav-link active">
                                        Home
                                        <i class="bx bx-chevron-down"></i>
                                    </a>

                                </li>
                                <li class="nav-item">
                                    <a href="about-us.php" class="nav-link active">
                                        About Us
                                        <i class="bx bx-chevron-down"></i>
                                    </a>

                                </li>


                                <li class="nav-item">
                                    <a href="services.php" class="nav-link">
                                        Services
                                        <i class="bx bx-chevron-down"></i>
                                    </a>

                                </li>
                                <li class="nav-item">
                                    <a href="blog.php" class="nav-link">
                                        Blog
                                        <i class="bx bx-chevron-down"></i>
                                    </a>

                                </li>

                                <li class="nav-item">
                                    <a href="contact.php" class="nav-link">Contact Us<i class="bx bx-chevron-down"></i></a>
                                </li>
                               
                            </ul>

                        </div>
                    </nav>
        </div>
    </div>

</div>
