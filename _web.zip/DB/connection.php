<?php
    $connection = mysqli_connect('localhost', 'jyoti_ayur', 'sa5msa5m@', 'jyoti_ayur');
    $siteUrl = 'https://jyotiayurclinic.com/';
